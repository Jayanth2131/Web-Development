Job Portal - JWT + Resume Upload Ready Project
----------------------------------------------

Backend:
  1. cd backend
  2. npm install
  3. Edit .env and replace <db_password> with your MongoDB Atlas password
  4. npm start
  API endpoints:
    GET /api/jobs
    POST /api/jobs (requires employer JWT)
    DELETE /api/jobs/:id (requires owner employer JWT)
    POST /api/users/register
    POST /api/users/login
    POST /api/users/upload-resume (requires JWT, form-data field 'resume')

Frontend:
  Open frontend/index.html in the browser. The frontend expects the API at http://localhost:5000/api

Notes:
  - Login/Register responses include a JWT token stored in localStorage.
  - Resume upload saves the file to backend/uploads and the public URL is /uploads/<filename>.
  - This is a demo flow; for production add HTTPS, stronger JWT handling and refresh tokens.
