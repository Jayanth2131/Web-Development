#!/usr/bin/env bash
# Simple end-to-end test script for the Job Portal (requires server running at http://localhost:5001)
# Usage: bash run_tests.sh
BASE=http://localhost:5001/api
echo "Running sanity tests against $BASE ..."

# 1) Register employer
EMP_EMAIL=employer_test@example.com
EMP_PASS=Password123
echo "Registering employer..."
curl -s -X POST $BASE/users/register -H "Content-Type: application/json" -d '{"name":"Employer Test","email":"'"$EMP_EMAIL"'","password":"'"$EMP_PASS"'","role":"employer"}' | jq || true

# 2) Login employer
EMP_TOKEN=$(curl -s -X POST $BASE/users/login -H "Content-Type: application/json" -d '{"email":"'"$EMP_EMAIL"'","password":"'"$EMP_PASS"'"}' | jq -r '.token')
echo "Employer token: $EMP_TOKEN"

# 3) Create job (as employer)
JOB_ID=$(curl -s -X POST $BASE/jobs -H "Authorization: Bearer $EMP_TOKEN" -F "title=Test Job" -F "description=Test description" -F "company=TestCo" | jq -r '.job._id')
echo "Created job: $JOB_ID"

# 4) Register user
USR_EMAIL=user_test@example.com
USR_PASS=Password123
curl -s -X POST $BASE/users/register -H "Content-Type: application/json" -d '{"name":"User Test","email":"'"$USR_EMAIL"'","password":"'"$USR_PASS"'","role":"user"}' | jq || true

# 5) Login user
USR_TOKEN=$(curl -s -X POST $BASE/users/login -H "Content-Type: application/json" -d '{"email":"'"$USR_EMAIL"'","password":"'"$USR_PASS"'"}' | jq -r '.token')
echo "User token: $USR_TOKEN"

# 6) Apply to job (requires test_resume.pdf present in root)
if [ -f test_resume.pdf ]; then
  curl -s -X POST $BASE/jobs/$JOB_ID/apply -H "Authorization: Bearer $USR_TOKEN" -F "name=User Test" -F "email=$USR_EMAIL" -F "resume=@test_resume.pdf" | jq
else
  echo "test_resume.pdf not found - please place a sample PDF named test_resume.pdf in the project root to test file upload."
fi

# 7) Employer fetch applicants
curl -s -X GET $BASE/jobs/$JOB_ID/applicants -H "Authorization: Bearer $EMP_TOKEN" | jq
echo "Test script complete."
