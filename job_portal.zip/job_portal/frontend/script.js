const socket = (typeof io !== 'undefined') ? io(location.origin) : null;
const API = '/api';

function saveAuth(token, user){ localStorage.setItem('token', token); localStorage.setItem('user', JSON.stringify(user)); localStorage.setItem('userName', user.name || user.email); renderNav(); }
function logout(){ localStorage.removeItem('token'); localStorage.removeItem('user'); localStorage.removeItem('userName'); window.location = '/'; }
function getToken(){ return localStorage.getItem('token'); }
function getUser(){ return JSON.parse(localStorage.getItem('user') || 'null'); }

function authFetch(url, opts = {}){
  const token = getToken();
  opts.headers = opts.headers || {};
  if(!opts.headers['Content-Type'] && !(opts.body instanceof FormData)) opts.headers['Content-Type'] = 'application/json';
  if(token) opts.headers['Authorization'] = 'Bearer ' + token;
  return fetch(url, opts);
}

async function loadJobs(){
  try{
    const res = await fetch(API + '/jobs');
    const jobs = await res.json();
    const container = document.getElementById('jobs');
    if(!container) return;
    container.innerHTML = '';
    jobs.forEach(j => {
      const el = document.createElement('div');
      el.className = 'job';
      el.innerHTML = `<h3>${escapeHtml(j.title || '')}</h3><p class="muted">${j.company || ''} • ${j.location || ''}</p><p>${(j.description || '').slice(0,160)}</p><div style="margin-top:10px"><a class="btn" href="/apply.html?job=${j._id}" onclick="setSelectedJob('${j._id}','${j.title||''}')">Apply</a></div>`;
      container.appendChild(el);
    });
  }catch(err){ console.error(err); }
}

document.addEventListener('submit', async (e) => {
  const id = e.target && e.target.id;
  if(id === 'registerForm'){
    e.preventDefault();
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const role = document.getElementById('role').value;
    const res = await fetch(API + '/users/register', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({name,email,password,role})});
    const json = await res.json();
    if(res.ok){ alert('Registered - please login'); window.location='/login.html'; } else { alert(json.message || json.error || 'Error'); }
  } else if(id === 'loginForm'){
    e.preventDefault();
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const res = await fetch(API + '/users/login', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({email,password})});
    const json = await res.json();
    if(res.ok){ saveAuth(json.token, json.user); alert('Login successful'); window.location='/dashboard.html'; } else { alert(json.message || json.error || 'Login failed'); }
  } else if(id === 'jobForm'){
    e.preventDefault();
    const title = document.getElementById('title').value;
    const company = document.getElementById('company').value;
    const location = document.getElementById('location').value;
    const salary = document.getElementById('salary').value;
    const description = document.getElementById('description').value;
    const res = await authFetch(API + '/jobs', {method:'POST', body:JSON.stringify({title,company,location,salary,description})});
    const json = await res.json();
    if(res.ok){ alert('Job created'); window.location='/employer-dashboard.html'; } else { alert(json.message || json.error || 'Error'); }
  } else if(id === 'resumeForm'){
    e.preventDefault();
    const fileInput = document.getElementById('resumeFile');
    if(!fileInput || !fileInput.files[0]){ alert('Choose a file'); return; }
    const fd = new FormData(); fd.append('resume', fileInput.files[0]);
    const token = getToken(); if(!token){ alert('Please login'); return; }
    const res = await fetch(API + '/users/upload-resume', {method:'POST', body: fd, headers: { 'Authorization': 'Bearer ' + token }});
    const json = await res.json(); if(res.ok){ alert('Resume uploaded'); } else { alert(json.message || json.error || 'Error'); }
  } else if(id === 'applyForm'){
    e.preventDefault();
    const params = new URLSearchParams(location.search); const jobId = params.get('job'); const form = document.getElementById('applyForm'); const fd = new FormData(form); const token = getToken(); if(!token){ alert('Please login'); window.location.href = '/login.html'; return; } const res = await fetch(API + '/jobs/' + jobId + '/apply', {method:'POST', body: fd, headers: { 'Authorization': 'Bearer ' + token }}); const json = await res.json(); if(res.ok){ alert('Applied'); window.location='/user-dashboard.html'; } else { alert(json.message || json.error || 'Error'); }
  } else if(id === 'profileForm'){
    e.preventDefault();
    const name = document.getElementById('profileName').value;
    const email = document.getElementById('profileEmail').value;
    const token = getToken(); if(!token){ alert('Please login'); return; }
    const res = await fetch(API + '/users/profile', {method:'PUT', headers:{'Content-Type':'application/json','Authorization':'Bearer '+token}, body: JSON.stringify({name,email})});
    const json = await res.json(); if(res.ok){ alert('Profile updated'); saveAuth(token, json.user); } else { alert(json.message || json.error || 'Error'); }
  }
});

async function loadJobsForUser(){
  try{
    const res = await fetch(API + '/jobs');
    const jobs = await res.json();
    const container = document.getElementById('jobList');
    if(!container) return;
    container.innerHTML = '';
    const userEmail = JSON.parse(localStorage.getItem('user')||'null')?.email;
    jobs.forEach(j => {
      const already = j.applicants.some(a=>a.email===userEmail);
      const el = document.createElement('div');
      el.className = 'job';
      el.innerHTML = `<h3>${escapeHtml(j.title || '')}</h3><p class="muted">${j.company || ''} • ${j.location || ''}</p><p>${(j.description || '').slice(0,160)}</p><div style="margin-top:10px"><button class="btn" ${already? 'disabled': ''} onclick="applyFromList('${j._id}', this)">${already? 'Applied':'Apply'}</button></div>`;
      container.appendChild(el);
    });
  }catch(err){ console.error(err); }
}

async function applyFromList(jobId, btn){
  const token = getToken(); if(!token){ alert('Please login'); window.location.href = '/login.html'; return; }
  try{
    const res = await fetch(API + '/jobs/' + jobId + '/apply', {method:'POST', headers:{'Authorization':'Bearer '+token}});
    const json = await res.json();
    if(res.ok){ alert('Applied successfully'); btn.textContent='Applied'; btn.disabled=true; loadUserApplications(); } else { alert(json.message || 'Error'); }
  }catch(e){ console.error(e); alert('Network error'); }
}

async function loadUserApplications(){
  try{
    const res = await fetch(API + '/jobs');
    const jobs = await res.json();
    const list = document.getElementById('applicationsList');
    if(!list) return;
    list.innerHTML='';
    const user = JSON.parse(localStorage.getItem('user')||'null');
    if(!user) return;
    jobs.forEach(j=>{
      j.applicants.forEach(a=>{
        if(a.email===user.email){
          const el = document.createElement('div');
          el.className='job';
          el.innerHTML = `<h3>${escapeHtml(j.title)}</h3><p class='muted'>${escapeHtml(j.company)} • ${escapeHtml(j.location)}</p><p>Status: <b>${escapeHtml(a.status)}</b></p><p>Applied: ${new Date(a.appliedAt).toLocaleString()}</p>`;
          list.appendChild(el);
        }
      });
    });
  }catch(e){ console.error(e); }
}

async function loadMyJobs(){
  try{
    const res = await authFetch(API + '/jobs/my');
    const jobs = await res.json();
    const container = document.getElementById('myJobs');
    if(!container) return;
    container.innerHTML='';
    jobs.forEach(j => {
      const total = j.applicants.length;
      const pending = j.applicants.filter(a=>a.status==='Pending').length;
      const accepted = j.applicants.filter(a=>a.status==='Accepted').length;
      const rejected = j.applicants.filter(a=>a.status==='Rejected').length;
      const el = document.createElement('div');
      el.className = 'job';
      el.innerHTML = `<h3>${escapeHtml(j.title)}</h3><p class='muted'>${escapeHtml(j.company)} • ${escapeHtml(j.location)}</p><p>Applicants: ${total} | Pending: ${pending} | Accepted: ${accepted} | Rejected: ${rejected}</p><div style='margin-top:10px'><a class='btn' href='/applicants.html?job=${j._id}'>View Applicants</a></div>`;
      container.appendChild(el);
    });
  }catch(e){ console.error(e); }
}

async function loadApplicantsPage(){
  const params = new URLSearchParams(location.search); const jobId = params.get('job'); if(!jobId) return;
  try{
    const res = await authFetch(API + '/jobs/' + jobId + '/applicants');
    const json = await res.json();
    if(!res.ok){ alert(json.message || 'Error'); return; }
    const area = document.getElementById('applicantsArea');
    if(!area) return;
    area.innerHTML = '';
    json.applicants.forEach((a, idx) => {
      const el = document.createElement('div');
      el.className='job';
      el.innerHTML = `<h3>${escapeHtml(a.name)}</h3><p class='muted'>${escapeHtml(a.email)}</p><p>Status: <b>${escapeHtml(a.status)}</b></p><p>${escapeHtml(a.cover||'')}</p>${a.resumeUrl?`<p><a class='btn' href='${a.resumeUrl}' target='_blank'>Download Resume</a></p>`:''}<div style='margin-top:8px'><select id='status_${idx}'><option value='Pending' ${a.status==='Pending'?'selected':''}>Pending</option><option value='Accepted' ${a.status==='Accepted'?'selected':''}>Accepted</option><option value='Rejected' ${a.status==='Rejected'?'selected':''}>Rejected</option></select> <button class='btn' onclick='updateApplicantStatus("${jobId}",${idx})'>Update</button></div>`;
      area.appendChild(el);
    });
  }catch(e){ console.error(e); }
}

async function updateApplicantStatus(jobId, idx){
  try{
    const sel = document.getElementById('status_'+idx);
    const status = sel.value;
    const res = await authFetch(API + '/jobs/' + jobId + '/applicants/' + idx + '/status', {method:'PUT', headers:{'Content-Type':'application/json'}, body: JSON.stringify({status})});
    const json = await res.json();
    if(res.ok){ alert('Status updated'); loadApplicantsPage(); } else { alert(json.message || json.error || 'Error'); }
  }catch(e){console.error(e);}
}

function escapeHtml(unsafe){ return (unsafe||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#039;'); }

function renderNav(){ const user = JSON.parse(localStorage.getItem('user')||'null'); const nav = document.getElementById('navlinks'); if(!nav) return; nav.innerHTML = ''; if(user){ const span = document.createElement('span'); span.textContent = 'Hello, ' + (user.name || user.email); nav.appendChild(span); const dash = document.createElement('a'); dash.href='/dashboard.html'; dash.textContent='Dashboard'; dash.style.marginLeft='12px'; nav.appendChild(dash); if(user.role==='employer'){ const post = document.createElement('a'); post.href='/addjob.html'; post.textContent='Post Job'; post.style.marginLeft='12px'; nav.appendChild(post); } const logoutBtn = document.createElement('a'); logoutBtn.href='#'; logoutBtn.textContent='Logout'; logoutBtn.style.marginLeft='12px'; logoutBtn.addEventListener('click',(e)=>{e.preventDefault(); logout();}); nav.appendChild(logoutBtn); } else { const l = document.createElement('a'); l.href='/login.html'; l.textContent='Login'; nav.appendChild(l); const r = document.createElement('a'); r.href='/register.html'; r.textContent='Register'; r.style.marginLeft='12px'; nav.appendChild(r); } }

async function deleteJob(e){ const id = e.currentTarget.dataset.id; if(!confirm('Delete job?')) return; const res = await authFetch(API + '/jobs/' + id, {method:'DELETE'}); const json = await res.json(); if(res.ok){ alert('Deleted'); loadMyJobs(); } else { alert(json.message || json.error); } }

if(socket){ socket.on('job:applied', data => { console.log('socket job:applied', data); if(typeof loadMyApplications==='function') loadMyApplications(); if(typeof loadApplicants==='function') loadApplicants(data.jobId); if(typeof loadJobs==='function') loadJobs(); }); socket.on('job:created', data => { console.log('socket job:created', data); if(typeof loadJobs==='function') loadJobs(); }); }

function setSelectedJob(id,title){ try{ localStorage.setItem('selectedJobId', id); if(title) localStorage.setItem('selectedJobTitle', title); }catch(e){} }
