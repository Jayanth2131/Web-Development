document.addEventListener('DOMContentLoaded', () => {
  const forms = document.querySelectorAll('form');
  forms.forEach(form => {
    form.addEventListener('submit', async (e)=>{
      e.preventDefault();
      const data = {};
      new FormData(form).forEach((v,k)=> data[k]=v);
      const action = form.getAttribute('action') || form.id || form.getAttribute('name') || '';
      const url = action.startsWith('/api') ? action : '/api/' + (action || form.id || form.name);
      try{
        const res = await fetch(url, { method: form.method||'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(data)});
        const j = await res.json();
        console.log('form submit', j);
        if(url.endsWith('/login') && j.success){ localStorage.setItem('token', j.token); localStorage.setItem('user', JSON.stringify(j.user)); if(j.user.role==='employer') window.location='/frontend/views/employer-dashboard.html'; else window.location='/frontend/views/user-dashboard.html'; }
        if(url.endsWith('/register') && j.success){ localStorage.setItem('token', j.token); localStorage.setItem('user', JSON.stringify(j.user)); if(j.user.role==='employer') window.location='/frontend/views/employer-dashboard.html'; else window.location='/frontend/views/user-dashboard.html'; }
      }catch(err){ console.error(err); alert('Request failed'); }
    });
  });
});