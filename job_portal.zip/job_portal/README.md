# Job Portal - Deployment

## Overview
This project is a Job Listing Portal (frontend + backend). The backend serves APIs and static frontend files (fallback to `frontend/index.html`).

## Environment (MongoDB Atlas)
Create a `.env` file in the `backend` folder with these values (replace with your Atlas connection string):

```
MONGO_URI=mongodb+srv://<user>:<password>@cluster0.mongodb.net/your-db?retryWrites=true&w=majority
JWT_SECRET=your_jwt_secret
PORT=5001
```

## Local run (recommended)
1. Backend:
```bash
cd backend
npm install
cp .env.example .env   # then edit .env to fill MONGO_URI and JWT_SECRET
node server.js
```
2. Frontend (optional if using unified server):
The backend serves the frontend automatically. If you want to serve frontend separately for development:
```bash
cd frontend
npx http-server -p 8080
```

## Docker (single-container)
Build and run with Docker (make sure `.env` is configured for Atlas):
```bash
docker build -t job-portal .
docker run -p 5001:5001 --env-file backend/.env -d job-portal
```
Now open `http://localhost:5001` to access the app.

## Deploy to Render / Railway / VPS
- Set environment variables `MONGO_URI`, `JWT_SECRET`, `PORT` in the service dashboard.
- Use the Dockerfile or run `npm install` then `node server.js` in the `backend` directory.

## Notes
- Frontend fetches APIs from `/api` (same host), and Socket.IO connects to `location.origin` (works in deployed host).
- For file uploads, `backend/uploads` stores uploaded resumes. Ensure persistent storage in production or configure an S3-compatible storage.

