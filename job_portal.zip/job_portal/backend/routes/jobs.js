import express from 'express';
import Job from '../models/Job.js';
import User from '../models/User.js';
import { authenticate, authorizeRole } from '../middleware/auth.js';
import multer from 'multer';
import path from 'path';
import { fileURLToPath } from 'url';
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const uploadDir = path.join(__dirname, '..', 'uploads');
import fs from 'fs';
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });
const storage = multer.diskStorage({
  destination: function (req, file, cb) { cb(null, uploadDir); },
  filename: function (req, file, cb) { cb(null, Date.now() + '-' + Math.round(Math.random()*1E9) + path.extname(file.originalname)); }
});
function isAllowedResume(file){
  const allowed = ['.pdf','.doc','.docx'];
  const ext = path.extname(file.originalname).toLowerCase();
  return allowed.includes(ext);
}
const upload = multer({
  storage,
  limits: { fileSize: 2 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    if (isAllowedResume(file)) cb(null, true); else cb(new Error('Invalid file type. Allowed: pdf, doc, docx'));
  }
});

const router = express.Router();

// list jobs with basic search filters
router.get('/', async (req, res) => {
  try {
    const { q, type, location } = req.query;
    const filter = {};
    if (q) {
      const regex = new RegExp(q, 'i');
      filter.$or = [
        { title: regex },
        { description: regex },
        { company: regex },
        { responsibilities: regex },
        { qualifications: regex },
      ];
    }
    if (type) filter.type = type;
    if (location) filter.location = new RegExp(`^${location}$`, 'i');
    const jobs = await Job.find(filter)
      .populate('postedBy', 'name email role')
      .sort({ createdAt: -1 });
    res.json(jobs);
  } catch (err) { res.status(500).json({ error: err.message }); }
});
// create job (employer)
router.post('/', authenticate, authorizeRole('employer'), async (req, res) => {
  try {
    const { title, description, qualifications, responsibilities, company, location, type, salary } = req.body;
    const job = new Job({ title, description, qualifications, responsibilities, company, location, type, salary, postedBy: req.user.id });
    await job.save();
    res.status(201).json({ message: 'Job created', job });
  } catch(err){ res.status(500).json({ error: err.message }); }
});
// my jobs
router.get('/my', authenticate, authorizeRole('employer'), async (req, res) => {
  try { const jobs = await Job.find({ postedBy: req.user.id }).sort({ createdAt: -1 }); res.json(jobs); } catch(err){ res.status(500).json({ error: err.message }); }
});

// update job (employer)
router.put('/:id', authenticate, authorizeRole('employer'), async (req, res) => {
  try {
    const job = await Job.findById(req.params.id);
    if(!job) return res.status(404).json({ message: 'Job not found' });
    if(String(job.postedBy) !== String(req.user.id)) return res.status(403).json({ message: 'Forbidden' });
    const fields = ['title','description','qualifications','responsibilities','company','location','type','salary'];
    fields.forEach(f => { if (req.body[f] !== undefined) job[f] = req.body[f]; });
    await job.save();
    res.json({ message: 'Job updated', job });
  } catch(err){ res.status(500).json({ error: err.message }); }
});
// apply
router.post('/:id/apply', authenticate, authorizeRole('user'), upload.single('resume'), async (req, res) => {
  try {
    const job = await Job.findById(req.params.id);
    const user = await User.findById(req.user.id);
    if(!job) return res.status(404).json({ message: 'Job not found' });
    if(job.applicants.some(a=>a.email===user.email)) return res.status(400).json({ message: 'Already applied' });
    const applicant = { name: user.name, email: user.email, cover: req.body.cover || '', resumeUrl: req.file ? '/uploads/' + req.file.filename : (user.resumeUrl || '') };
    job.applicants.push(applicant);
    await job.save();
    // emit real-time update to employer and user dashboards
    try{ const io = req.app.get('io'); if(io) io.emit('job:applied', { jobId: job._id, applicant }); }catch(e){console.warn('io emit failed', e);} 
    res.json({ message: 'Applied', applicant });
  } catch(err){ res.status(500).json({ error: err.message }); }
});
// applicants
router.get('/:id/applicants', authenticate, authorizeRole('employer'), async (req, res) => {
  try {
    const job = await Job.findById(req.params.id);
    if(!job) return res.status(404).json({ message: 'Job not found' });
    if(String(job.postedBy) !== String(req.user.id)) return res.status(403).json({ message: 'Forbidden' });
    res.json({ applicants: job.applicants });
  } catch(err){ res.status(500).json({ error: err.message }); }
});

// update applicant status by index
router.put('/:jobId/applicants/:appIndex/status', authenticate, authorizeRole('employer'), async (req, res) => {
  try {
    const { jobId, appIndex } = req.params;
    const { status } = req.body;
    const job = await Job.findById(jobId);
    if(!job) return res.status(404).json({ message: 'Job not found' });
    if(String(job.postedBy) !== String(req.user.id)) return res.status(403).json({ message: 'Forbidden' });
    if(!['Pending','Accepted','Rejected'].includes(status)) return res.status(400).json({ message: 'Invalid status' });
    const idx = parseInt(appIndex,10);
    if(isNaN(idx) || !job.applicants[idx]) return res.status(400).json({ message: 'Applicant not found' });
    job.applicants[idx].status = status;
    await job.save();
    res.json({ message: 'Status updated', applicant: job.applicants[idx] });
  } catch(err){ res.status(500).json({ error: err.message }); }
});

// delete job
router.delete('/:id', authenticate, authorizeRole('employer'), async (req, res) => {
  try {
    const job = await Job.findById(req.params.id);
    if(!job) return res.status(404).json({ message: 'Not found' });
    if(String(job.postedBy) !== String(req.user.id)) return res.status(403).json({ message: 'Forbidden' });
    await job.deleteOne();
    res.json({ message: 'Deleted' });
  } catch(err){ res.status(500).json({ error: err.message }); }
});

export default router;
