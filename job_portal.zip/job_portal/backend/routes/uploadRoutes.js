const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const storage = multer.diskStorage({ destination: (req,file,cb)=>cb(null,path.join(__dirname,'..','uploads')), filename:(req,file,cb)=>cb(null,Date.now()+'-'+file.originalname) });
const upload = multer({ storage });
router.post('/uploadResume', upload.single('resume'), (req,res)=>{ if(!req.file) return res.status(400).json({success:false}); res.json({success:true,path:'/uploads/'+req.file.filename}); });
module.exports = router;
