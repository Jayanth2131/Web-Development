const express = require('express');
const router = express.Router();
const empCtrl = require('../controllers/employerController');
const auth = require('../middleware/authMiddleware');

router.get('/me', auth, empCtrl.getEmployer);

module.exports = router;
