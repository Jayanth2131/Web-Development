const express = require('express');
const router = express.Router();
const userCtrl = require('../controllers/userController');
const auth = require('../middleware/authMiddleware');

router.get('/me', auth, userCtrl.getProfile);

module.exports = router;
