const express = require('express');
const router = express.Router();
const auth = require('../middleware/authMiddleware');
const appCtrl = require('../controllers/applicationController');

router.post('/', auth, appCtrl.apply);
router.get('/employer/:employerId', auth, appCtrl.getApplicationsForEmployer);

module.exports = router;
