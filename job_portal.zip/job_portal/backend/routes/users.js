import { authenticate } from '../middleware/auth.js';
import express from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import dotenv from 'dotenv';
import User from '../models/User.js';
import Job from '../models/Job.js';
import multer from 'multer';
import path from 'path';
import { fileURLToPath } from 'url';
dotenv.config();

const router = express.Router();
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const uploadDir = path.join(__dirname, '..', 'uploads');
import fs from 'fs';
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });

const storage = multer.diskStorage({
  destination: function (req, file, cb) { cb(null, uploadDir); },
  filename: function (req, file, cb) { cb(null, Date.now() + '-' + Math.round(Math.random()*1E9) + path.extname(file.originalname)); }
});
function isAllowedResume(file){
  const allowed = ['.pdf','.doc','.docx'];
  const ext = path.extname(file.originalname).toLowerCase();
  return allowed.includes(ext);
}
const upload = multer({
  storage,
  limits: { fileSize: 2 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    if (isAllowedResume(file)) cb(null, true); else cb(new Error('Invalid file type. Allowed: pdf, doc, docx'));
  }
});

// Register
router.post('/register', async (req, res) => {
  try {
    const { name, email, password, role } = req.body;
    const existing = await User.findOne({ email });
    if (existing) return res.status(400).json({ message: 'User already exists' });
    const hashed = await bcrypt.hash(password, 10);
    const user = new User({ name, email, password: hashed, role });
    await user.save();
    res.status(201).json({ message: 'User registered successfully', user: { name: user.name, email: user.email, role: user.role } });
  } catch (err) {
    console.error('Register error', err);
    res.status(500).json({ message: 'Registration failed', error: err.message });
  }
});

// Login
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email });
    if (!user) return res.status(400).json({ message: 'Invalid email or password' });
    const ok = await bcrypt.compare(password, user.password);
    if (!ok) return res.status(400).json({ message: 'Invalid email or password' });
    const secret = process.env.JWT_SECRET || 'devsecret';
    const token = jwt.sign({ id: user._id, role: user.role, name: user.name, email: user.email }, secret, { expiresIn: '7d' });
    res.json({ message: 'Login successful', token, user: { name: user.name, email: user.email, role: user.role } });
  } catch (err) {
    console.error('Login error', err);
    res.status(500).json({ message: 'Login failed', error: err.message });
  }
});

// Update profile (supports employer fields)
router.put('/profile', async (req, res) => {
  try {
    const authHeader = req.headers.authorization || '';
    const token = authHeader.split(' ')[1];
    if (!token) return res.status(401).json({ message: 'No token' });
    const secret = process.env.JWT_SECRET || 'devsecret';
    const payload = jwt.verify(token, secret);
    const user = await User.findById(payload.id);
    if (!user) return res.status(404).json({ message: 'User not found' });
    const { name, email, phone, address, companyName, companyWebsite, companyDescription, contactPhone } = req.body;
    if (name !== undefined) user.name = name;
    if (email !== undefined) user.email = email;
    if (phone !== undefined) user.phone = phone;
    if (address !== undefined) user.address = address;
    if (user.role === 'employer') {
      if (companyName !== undefined) user.companyName = companyName;
      if (companyWebsite !== undefined) user.companyWebsite = companyWebsite;
      if (companyDescription !== undefined) user.companyDescription = companyDescription;
      if (contactPhone !== undefined) user.contactPhone = contactPhone;
    }
    await user.save();
    res.json({ message: 'Profile updated', user: { name: user.name, email: user.email, role: user.role, phone: user.phone, address: user.address, companyName: user.companyName, companyWebsite: user.companyWebsite, companyDescription: user.companyDescription, contactPhone: user.contactPhone } });
  } catch (err) {
    console.error('Profile update error', err);
    res.status(500).json({ message: 'Profile update failed', error: err.message });
  }
});

// Upload resume
router.post('/upload-resume', upload.single('resume'), async (req, res) => {
  try {
    const authHeader = req.headers.authorization || '';
    const token = authHeader.split(' ')[1];
    if (!token) return res.status(401).json({ message: 'No token' });
    const secret = process.env.JWT_SECRET || 'devsecret';
    const payload = jwt.verify(token, secret);
    const user = await User.findById(payload.id);
    if (!user) return res.status(404).json({ message: 'User not found' });
    user.resumeUrl = '/uploads/' + req.file.filename;
    await user.save();
    res.json({ message: 'Resume uploaded', resumeUrl: user.resumeUrl });
  } catch (err) {
    console.error('Upload resume error', err);
    res.status(500).json({ message: 'Upload failed', error: err.message });
  }
});

export default router;
// get my applications (job seeker)
router.get('/applications', async (req, res) => {
  try {
    const authHeader = req.headers.authorization || '';
    const token = authHeader.split(' ')[1];
    if (!token) return res.status(401).json({ message: 'No token' });
    const secret = process.env.JWT_SECRET || 'devsecret';
    const payload = jwt.verify(token, secret);
    const user = await User.findById(payload.id);
    if (!user) return res.status(404).json({ message: 'User not found' });
    const jobs = await Job.find({ 'applicants.email': user.email }).sort({ createdAt: -1 });
    res.json({ jobs });
  } catch (err) {
    console.error('Get applications error', err);
    res.status(500).json({ message: 'Failed to load applications', error: err.message });
  }
});

// Get current user profile
router.get('/me', async (req, res) => {
  try {
    const authHeader = req.headers.authorization || '';
    const token = authHeader.split(' ')[1];
    if (!token) return res.status(401).json({ message: 'No token' });
    const secret = process.env.JWT_SECRET || 'devsecret';
    const payload = jwt.verify(token, secret);
    const user = await User.findById(payload.id).lean();
    if (!user) return res.status(404).json({ message: 'User not found' });
    const { name, email, role, phone, address, companyName, companyWebsite, companyDescription, contactPhone, resumeUrl } = user;
    res.json({ name, email, role, phone, address, companyName, companyWebsite, companyDescription, contactPhone, resumeUrl });
  } catch (err) {
    console.error('Get me error', err);
    res.status(500).json({ message: 'Failed to load profile', error: err.message });
  }
});


// update profile (supports resume upload)
router.put('/me', authenticate, upload.single('resume'), async (req, res) => {
  try{
    const user = await User.findById(req.user.id);
    if(!user) return res.status(404).json({ message: 'User not found' });
    const { name, email, phone, address, companyName, companyWebsite, companyDescription, contactPhone } = req.body;
    if(name !== undefined) user.name = name;
    if(email !== undefined) user.email = email;
    if(phone !== undefined) user.phone = phone;
    if(address !== undefined) user.address = address;
    if(user.role === 'employer'){
      if(companyName !== undefined) user.companyName = companyName;
      if(companyWebsite !== undefined) user.companyWebsite = companyWebsite;
      if(companyDescription !== undefined) user.companyDescription = companyDescription;
      if(contactPhone !== undefined) user.contactPhone = contactPhone;
    }
    if(req.file) user.resumeUrl = '/uploads/' + req.file.filename;
    await user.save();
    res.json({ message: 'Profile updated', user: { name: user.name, email: user.email, role: user.role, companyName: user.companyName, companyWebsite: user.companyWebsite, companyDescription: user.companyDescription, contactPhone: user.contactPhone, phone: user.phone, address: user.address, resumeUrl: user.resumeUrl } });
  }catch(err){ console.error(err); res.status(500).json({ error: err.message }); }
});
