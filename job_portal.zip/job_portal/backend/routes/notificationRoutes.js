const express = require('express');
const router = express.Router();
const notifCtrl = require('../controllers/notificationController');

router.post('/send', notifCtrl.sendNotification);

module.exports = router;
