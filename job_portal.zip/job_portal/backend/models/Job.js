import mongoose from "mongoose";

const applicantSchema = new mongoose.Schema(
  {
    name: String,
    email: String,
    cover: String,
    resumeUrl: String,
    status: { type: String, enum: ["Pending", "Accepted", "Rejected"], default: "Pending" },
  },
  { timestamps: { createdAt: "appliedAt", updatedAt: false } }
);

const jobSchema = new mongoose.Schema(
  {
    title: { type: String, required: true },
    description: String,
    qualifications: String,
    responsibilities: String,
    company: String,
    location: String,
    type: String,
    salary: String,
    postedBy: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    applicants: [applicantSchema],
  },
  { timestamps: true }
);

export default mongoose.model("Job", jobSchema);
