import mongoose from 'mongoose';

const userSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true },
  email: { type: String, required: true, unique: true, lowercase: true, trim: true },
  password: { type: String, required: true },
  role: { type: String, enum: ['user','employer'], default: 'user' },
  resumeUrl: String,
  // job seeker contact fields
  phone: String,
  address: String,
  // employer profile fields (optional; used when role==='employer')
  companyName: String,
  companyWebsite: String,
  companyDescription: String,
  contactPhone: String
}, { timestamps: true });

export default mongoose.model('User', userSchema);
