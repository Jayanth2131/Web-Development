exports.getProfile = async (req,res)=>{ res.json({success:true, user:{ id: req.userId }}); };
