exports.sendNotification = (req,res)=>{ res.json({success:true,message:'not implemented'}); };
