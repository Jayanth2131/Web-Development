const Job = require('../models/Job');

exports.createJob = async (req, res) => {
  try {
    const { title, company, description, location, salary } = req.body;
    const employer = req.userId || req.body.employer || null;
    if (!title) return res.status(400).json({ success: false, message: 'Title required' });
    const job = await Job.create({ title, company, description, location, salary, employer });
    res.json({ success: true, job });
  } catch (err) {
    console.error('Create Job Error:', err);
    res.status(500).json({ success: false, message: err.message });
  }
};

exports.listJobs = async (req, res) => {
  try {
    const q = req.query.q || '';
    const location = req.query.location || '';
    const salaryMin = req.query.salaryMin || '';
    const filter = {};
    if (q) filter.$or = [{ title: new RegExp(q, 'i') }, { company: new RegExp(q, 'i') }, { description: new RegExp(q, 'i') }];
    if (location) filter.location = new RegExp(location, 'i');
    if (salaryMin) filter.salary = { $gte: parseInt(salaryMin) || 0 };
    const jobs = await Job.find(filter).sort({ createdAt: -1 });
    res.json({ success: true, jobs });
  } catch (err) {
    console.error('List Jobs Error:', err);
    res.status(500).json({ success: false, message: err.message });
  }
};

exports.getJob = async (req, res) => {
  try {
    const job = await Job.findById(req.params.id);
    if (!job) return res.status(404).json({ success: false, message: 'Job not found' });
    res.json({ success: true, job });
  } catch (err) {
    console.error('Get Job Error:', err);
    res.status(500).json({ success: false, message: err.message });
  }
};

exports.updateJob = async (req, res) => {
  try {
    const job = await Job.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!job) return res.status(404).json({ success: false, message: 'Job not found' });
    res.json({ success: true, job });
  } catch (err) {
    console.error('Update Job Error:', err);
    res.status(500).json({ success: false, message: err.message });
  }
};

exports.deleteJob = async (req, res) => {
  try {
    const job = await Job.findByIdAndDelete(req.params.id);
    if (!job) return res.status(404).json({ success: false, message: 'Job not found' });
    res.json({ success: true, message: 'Job deleted successfully' });
  } catch (err) {
    console.error('Delete Job Error:', err);
    res.status(500).json({ success: false, message: err.message });
  }
};
