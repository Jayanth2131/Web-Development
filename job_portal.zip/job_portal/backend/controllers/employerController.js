exports.getEmployer = async (req,res)=>{ res.json({success:true, employer:{ id: req.userId }}); };
