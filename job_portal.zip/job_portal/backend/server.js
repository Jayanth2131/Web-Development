import express from 'express';
import mongoose from 'mongoose';
import cors from 'cors';
import dotenv from 'dotenv';
import bodyParser from 'body-parser';
import jobRoutes from './routes/jobs.js';
import userRoutes from './routes/users.js';
import path from 'path';
import { fileURLToPath } from 'url';
import seedJobs from './seed.js';

dotenv.config();
const app = express();
import http from 'http';
import { Server as SocketIO } from 'socket.io';
app.use(cors());
app.use(bodyParser.json());

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// static uploads and frontend
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));
app.use(express.static(path.join(__dirname, '..', 'frontend')));

const mongoUri = process.env.MONGO_URI || 'mongodb://localhost:27017/jobportal';
mongoose.connect(mongoUri)
  .then(async () => {
    console.log('✅ MongoDB connected successfully');
    try { await seedJobs(); } catch(e){ console.log('Seed error', e.message); }
  })
  .catch((err) => console.error('❌ MongoDB connection error:', err));

app.use('/api/jobs', jobRoutes);
app.use('/api/users', userRoutes);

// fallback to frontend index
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'frontend', 'index.html'));
});

const PORT = process.env.PORT || 5001;
const server = http.createServer(app);
const io = new SocketIO(server, { cors: { origin: '*'} });
app.set('io', io);
io.on('connection', socket => { console.log('Socket connected', socket.id); });
server.listen(PORT, () => console.log(`🚀 Server running on port ${PORT}`));
