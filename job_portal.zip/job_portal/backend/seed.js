import Job from './models/Job.js';

const sampleJobs = [
  { title: "Frontend Developer", company: "Acme Tech", location: "Remote", salary: "₹40k - ₹80k", description: "React, HTML, CSS expertise required." },
  { title: "Backend Developer (.NET)", company: "GlobalSoft", location: "Bengaluru", salary: "₹50k - ₹1L", description: "C#, .NET Core, SQL Server." },
  { title: "Full Stack Engineer", company: "InnovateX", location: "Hyderabad", salary: "₹60k - ₹1.2L", description: "MERN stack required." }
];

export default async function seedJobs(){
  const count = await Job.countDocuments();
  if(count === 0){
    await Job.insertMany(sampleJobs.map(j => ({ ...j })));
    console.log('Seeded sample jobs:', sampleJobs.length);
  } else {
    console.log('Jobs already present:', count);
  }
}
